const loading = document.getElementById('loading');
const channelSelector = document.getElementById('channelSelector');
const channelName = document.getElementById('channel-name');

fetch('channels.json')
  .then(res => res.json())
  .then(channels => {
    channels.forEach(ch => {
      const opt = document.createElement('option');
      opt.value = ch.file;
      opt.text = ch.name;
      channelSelector.appendChild(opt);
    });

    const first = channels[0];
    channelName.innerText = first.name;
    loadPlayer(first.file);

    channelSelector.addEventListener('change', () => {
      const selected = channels.find(c => c.file === channelSelector.value);
      channelName.innerText = selected.name;
      loadPlayer(selected.file);
    });
  });

function loadPlayer(url) {
  loading.style.display = 'flex';
  jwplayer("player").setup({
    file: url,
    autostart: true,
    width: "100%",
    height: "100%",
    controls: true,
    primary: "html5"
  }).on('play', () => {
    loading.style.display = 'none';
  });
}
