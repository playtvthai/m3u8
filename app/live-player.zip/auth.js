if (localStorage.getItem("auth") !== "1") {
  window.location.href = "login.html";
}
